"""
The melting temperature(tm) is the temp at which one half of a particular DNA will disociate and become a single strand of DNA primerland and seq are of critical importance in designing the parameters of a successful amplification.The tm of a nucleic acid duplex increases both with its length and with increasing GC content.
tm = 4( G + C) + 2(A + T)
tm = 81,5 + 16,6(log 10 ([Na+])) + .41*(%GC) - 600/length

Implement an app that computes the tm of a DNA seq, by using one of those formula on both of them.Input =  a string of DNA, Output = temp in Celsius
"""

import math

seq = input("Enter a DNA sequence: ")
seq = seq.upper()
na_conc = 0.0001

length = len(seq)
A, T, G, C = seq.count('A'), seq.count('T'), seq.count('G'), seq.count('C')

tm_first = 4 * (G + C) + 2 * (A + T)
tm_second = 81.5 + 16.6 * math.log10(na_conc) + 0.41 * ((G + C) / length * 100) - (600 / length)

tm_first = round(tm_first, 2)
tm_second = round(tm_second, 2)

print(f"\nFirst Tm formula: {tm_first} °C")
print(f"Second Tm formula: {tm_second} °C")

 
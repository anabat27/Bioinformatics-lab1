"""
Design an app that uses the sliding window method in order to read the tm over the sequence S.
Use a sliding window f 8 positions and choose a FASTA file as input.
"""

import math
from Bio import SeqIO

WINDOW_SIZE = 8
NA_CONC = 0.0001  # sodium concentration for second formula

fasta_path = input("Enter path to FASTA file: ")

# Read sequence from FASTA
with open(fasta_path) as f:
    record = next(SeqIO.parse(f, "fasta"))
    seq = str(record.seq).upper()

if len(seq) < WINDOW_SIZE:
    print("Error: Sequence shorter than sliding window size.")
    exit(1)

print(f"\nProcessing sequence: {record.id} ({len(seq)} bases)\n")

# Sliding window
for i in range(len(seq) - WINDOW_SIZE + 1):
    window = seq[i:i+WINDOW_SIZE]
    
    # Count nucleotides
    A = window.count('A')
    T = window.count('T')
    G = window.count('G')
    C = window.count('C')
    
    # Tm calculations
    tm_first = 4 * (G + C) + 2 * (A + T)
    tm_second = 81.5 + 16.6 * math.log10(NA_CONC) + 0.41 * ((G + C)/WINDOW_SIZE * 100) - (600 / WINDOW_SIZE)
    
    # Round results
    tm_first = round(tm_first, 2)
    tm_second = round(tm_second, 2)
    
    print(f"Window {i}-{i+WINDOW_SIZE-1} ({window}): Tm1 = {tm_first}°C, Tm2 = {tm_second}°C")



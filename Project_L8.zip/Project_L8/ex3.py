
import os

def read_fasta(file_path):
    dna_sequence = ""
    with open(file_path, "r") as f:
        for line in f:
            if not line.startswith(">"):  
                dna_sequence += line.strip()
    return dna_sequence.upper()  


folder_path = "C:/Users/ana/Desktop/anul4/bioinfo/Project_L8/bacterial_fastas"
genomes = {}

for filename in os.listdir(folder_path):
    if filename.endswith(".fasta") or filename.endswith(".fa"):
        file_path = os.path.join(folder_path, filename)
        genomes[filename] = read_fasta(file_path)

for name, seq in genomes.items():
    print(f"{name}: {len(seq)} bases")

def reverse_complement(seq):
    complement = {'A':'T', 'T':'A', 'C':'G', 'G':'C'}
    return ''.join(complement[base] for base in reversed(seq))

min_len = 4
max_len = 6
max_distance = 50  

inverted_repeats = {}

for name, seq in genomes.items():
    repeats = []
    seq_len = len(seq)
    for motif_len in range(min_len, max_len+1):
        for i in range(seq_len - motif_len):
            motif = seq[i:i+motif_len]
            rev_comp = reverse_complement(motif)
            for j in range(i+motif_len, min(i+motif_len+max_distance, seq_len - motif_len +1)):
                if seq[j:j+motif_len] == rev_comp:
                    repeats.append((i, j+motif_len, motif))
    inverted_repeats[name] = repeats

for name, repeats in inverted_repeats.items():
    print(f"\nGenome: {name}, total inverted repeats found: {len(repeats)}")
    for start, end, motif in repeats[:5]:  
        print(f"{motif} -> reverse complement at positions ({start}, {end})")



import random

def random_dna(length):
    return ''.join(random.choice('ACGT') for _ in range(length))

def transposable_element():
    pattern = random_dna(random.randint(4,7))
    space = random_dna(random.randint(3,8))
    return pattern, space, pattern[::-1]

dna = random_dna(random.randint(200,400))

te_info = []
num_tes = random.randint(3,4)

for _ in range(num_tes):
    while True:
        pos = random.randint(0, len(dna)-20)
        overlap = any(start <= pos <= end or start <= pos+20 <= end for start, end, *_ in te_info)
        if not overlap:
            break
    pattern, space, rev = transposable_element()
    te_full = pattern + space + rev
    dna = dna[:pos] + te_full + dna[pos+len(te_full):]
    te_info.append((pos, pos+len(te_full), pattern, space, rev))

te_info.sort()

print("Random DNA sequence (200-400 bases):\n")
print(dna)

print("\nTransposable elements with positions:\n")
for idx, (start, end, pattern, space, rev) in enumerate(te_info, 1):
    print(f"TE {idx}: {pattern}[{space}]{rev}, Position = ({start}, {end})")

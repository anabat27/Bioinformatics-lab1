import os
import re
import tkinter as tk
from tkinter import scrolledtext
import threading

def needleman_wunsch_chunk(s1, s2):
    m, n = len(s1), len(s2)
    score = [[0] * (n + 1) for _ in range(m + 1)]

    for i in range(1, m + 1):
        for j in range(1, n + 1):
            is_match = (s1[i-1] == s2[j-1])
            diag = score[i-1][j-1] + (1 if is_match else -1)
            up   = score[i-1][j] + 0
            left = score[i][j-1] + 0
            score[i][j] = max(diag, up, left)

    a1, a2 = "", ""
    i, j = m, n
    matches = 0

    while i > 0 and j > 0:
        is_match = (s1[i-1] == s2[j-1])
        diag_cost = 1 if is_match else -1
        
        if score[i][j] == score[i-1][j-1] + diag_cost:
            a1 += s1[i-1]; a2 += s2[j-1]
            if is_match: matches += 1
            i -= 1; j -= 1
        elif score[i][j] == score[i-1][j] + 0: 
            a1 += s1[i-1]; a2 += "-"; i -= 1
        else: 
            a1 += "-"; a2 += s2[j-1]; j -= 1

    while i > 0: a1 += s1[i-1]; a2 += "-"; i -= 1
    while j > 0: a1 += "-"; a2 += s2[j-1]; j -= 1

    return a1[::-1], a2[::-1], matches

def align_pair_of_genomes(genome1, genome2, window=500):
    full_a1, full_a2 = "", ""
    total_matches = 0
    max_len = max(len(genome1), len(genome2))

    for i in range(0, max_len, window):
        chunk1 = genome1[i : i + window]
        chunk2 = genome2[i : i + window]
        sub_a1, sub_a2, sub_matches = needleman_wunsch_chunk(chunk1, chunk2)
        
        full_a1 += sub_a1
        full_a2 += sub_a2
        total_matches += sub_matches

    return full_a1, full_a2, total_matches

def read_genomes_naturally(folder_path, log_func):
    data = [] 
    if not os.path.exists(folder_path):
        log_func(f"Error: Folder {folder_path} not found.\n")
        return []

    files = [f for f in os.listdir(folder_path) if f.endswith(".fasta") or f.endswith(".fa")]
    files.sort(key=lambda x: [int(c) if c.isdigit() else c for c in re.split(r'(\d+)', x)])
    
    for filename in files:
        path = os.path.join(folder_path, filename)
        seq = ""
        with open(path, "r") as f:
            for line in f:
                if not line.startswith(">"):
                    seq += line.strip()
        data.append((filename, seq.upper()))
        
    return data

class BioApp:
    def __init__(self, root):
        self.root = root
        self.root.title("HIV-1 Alignment Tool (Matrix Output)")
        self.root.geometry("1000x800") 

        top_frame = tk.Frame(root)
        top_frame.pack(pady=10)

        self.btn_run = tk.Button(top_frame, text="Start Alignment Analysis", command=self.start_thread, font=("Arial", 12), bg="lightblue")
        self.btn_run.pack()

        self.text_area = scrolledtext.ScrolledText(root, width=100, height=15, font=("Consolas", 9))
        self.text_area.pack(padx=10, pady=5)
        
        self.matrix_frame = tk.Frame(root)
        self.matrix_frame.pack(padx=10, pady=20, fill="both", expand=True)

    def log(self, message):
        self.text_area.insert(tk.END, message + "\n")
        self.text_area.see(tk.END)

    def start_thread(self):
        self.btn_run.config(state=tk.DISABLED, text="Running...")
        self.text_area.delete(1.0, tk.END)
        for widget in self.matrix_frame.winfo_children():
            widget.destroy()
            
        t = threading.Thread(target=self.run_process)
        t.start()

    def get_color(self, score):
        if score < 70: return "#ffffff"
        
        intensity = int(255 - ((score - 70) / 30 * 255))
        if intensity < 0: intensity = 0
        
        hex_color = f"#ff{intensity:02x}{intensity:02x}"
        return hex_color

    def run_process(self):
        FOLDER = "C:/Users/ana/Desktop/anul4/bioinfo/HIV-1 genomes"

        self.log(f"Reading genomes from: {FOLDER}...")
        genomes = read_genomes_naturally(FOLDER, self.log)
        count = len(genomes)
        
        matrix_data = [[0]*count for _ in range(count)]
        for i in range(count):
            matrix_data[i][i] = 100

        if count < 2:
            self.log("Not enough genomes.")
        else:
            self.log("Running All-vs-All Alignments...\n")
            
            for i in range(count):
                name1, seq1 = genomes[i]
                for j in range(i + 1, count):
                    name2, seq2 = genomes[j]

                    a1, a2, matches = align_pair_of_genomes(seq1, seq2, window=500)
                    length = len(a1)
                    similarity = int((matches / length) * 100) if length > 0 else 0

                    self.log(f"Processed: {name1} vs {name2} -> {similarity}%")
                    
                    matrix_data[i][j] = similarity
                    matrix_data[j][i] = similarity 

            self.root.after(0, lambda: self.draw_heatmap(genomes, matrix_data))
            self.log("\nDone! Check the Matrix below.")
        
        self.btn_run.config(state=tk.NORMAL, text="Start Alignment Analysis")

    def draw_heatmap(self, genomes, matrix_data):
        count = len(genomes)
        
        short_names = [name[0].replace("hiv-1_", "").replace(".fasta", "") for name in genomes]

        tk.Label(self.matrix_frame, text="IDs", font=("Arial", 9, "bold")).grid(row=0, column=0)
        for c in range(count):
            tk.Label(self.matrix_frame, text=short_names[c], width=6, font=("Arial", 9, "bold")).grid(row=0, column=c+1)

        for r in range(count):
            tk.Label(self.matrix_frame, text=short_names[r], font=("Arial", 9, "bold")).grid(row=r+1, column=0)
            
            for c in range(count):
                score = matrix_data[r][c]
                bg_color = self.get_color(score)
                
                lbl = tk.Label(self.matrix_frame, text=str(score), bg=bg_color, width=6, height=2, relief="solid", borderwidth=1)
                lbl.grid(row=r+1, column=c+1, padx=1, pady=1)


if __name__ == "__main__":
    root = tk.Tk()
    app = BioApp(root)
    root.mainloop()
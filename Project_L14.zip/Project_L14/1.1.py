def needleman_wunsch(s1, s2):
    m, n = len(s1), len(s2)
    gap_score = 0
    match_score = 1
    mismatch_score = -1

    score = [[0] * (n + 1) for _ in range(m + 1)]

    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if s1[i-1] == s2[j-1]:
                diagonal = score[i-1][j-1] + match_score
            else:
                diagonal = score[i-1][j-1] + mismatch_score
            
            up = score[i-1][j] + gap_score
            left = score[i][j-1] + gap_score
            
            score[i][j] = max(diagonal, up, left)

    align1, align2, visuals = "", "", ""
    i, j = m, n
    
    while i > 0 and j > 0:
        current_score = score[i][j]
        diagonal_val = score[i-1][j-1]
        up_val = score[i-1][j]
        
        is_match = (s1[i-1] == s2[j-1])
        diag_cost = match_score if is_match else mismatch_score

        if current_score == diagonal_val + diag_cost:
            align1 += s1[i-1]
            align2 += s2[j-1]
            visuals += "|" if is_match else " "
            i -= 1
            j -= 1
        elif current_score == up_val + gap_score:
            align1 += s1[i-1]
            align2 += "-"
            visuals += " "
            i -= 1
        else:
            align1 += "-"
            align2 += s2[j-1]
            visuals += " "
            j -= 1

    while i > 0:
        align1 += s1[i-1]; align2 += "-"; visuals += " "; i -= 1
    while j > 0:
        align1 += "-"; align2 += s2[j-1]; visuals += " "; j -= 1

    align1 = align1[::-1]
    align2 = align2[::-1]
    visuals = visuals[::-1]
    
    matches_count = visuals.count("|")
    total_len = len(align1)
    similarity = int((matches_count / total_len) * 100)

    print("Show Alignment:")
    print(align1)
    print(visuals)
    print(align2)
    print("")
    print(f"Matches    = {matches_count}")
    print(f"Length     = {total_len}") 
    print(f"Similarity = {similarity} %")
    print(f"Tracing back: M[{m},{n}]")

S1 = "ACCGTGAAGCCAATAC"
S2 = "AGCGTGCAGCCAATAC"
needleman_wunsch(S1, S2)
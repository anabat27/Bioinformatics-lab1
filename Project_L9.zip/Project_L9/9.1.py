import os
import re
import matplotlib.pyplot as plt

FILE_PATH = "C:/Users/ana/Desktop/anul4/bioinfo/lab5/homosapiens_brain.fasta"

RESTRICTION_ENZYMES = {
    "EcoRI":   {"site": "GAATTC", "pattern": "G.AATTC"},
    "BamHI":   {"site": "GGATCC", "pattern": "G.GATCC"},
    "HindIII": {"site": "AAGCTT", "pattern": "A.AGCTT"},
    "TaqI":    {"site": "TCGA",   "pattern": "T.CGA"},
    "HaeIII":  {"site": "GGCC",   "pattern": "GG.CC"}
}

def read_fasta(file_path):
    """Reads a FASTA file and returns the DNA sequence as a single uppercase string."""
    if not os.path.exists(file_path):
        print(f"File not found: {file_path}. Using placeholder 1500 bp sequence.")
        return "A" * 1500

    dna_sequence = ""
    with open(file_path, "r") as f:
        for line in f:
            if not line.startswith(">"):
                dna_sequence += line.strip()
    return dna_sequence.upper()


def digest_dna(dna, pattern):
    recog = pattern.replace('.', '')
    cut_index = pattern.find('.')
    positions = [m.start() + cut_index for m in re.finditer('(?=' + recog + ')', dna)]
    fragments = []
    start = 0
    for pos in sorted(positions):
        fragments.append(pos - start)
        start = pos
    fragments.append(len(dna) - start)
    return positions, fragments


def plot_gel(fragments_data, save_file=False, filename='simulated_gel.png'):
    enzymes = list(fragments_data.keys())
    num_enzymes = len(enzymes)
    
    plt.figure(figsize=(2*num_enzymes, 10))
    
    for lane_idx, enzyme in enumerate(enzymes):
        fragments = sorted(fragments_data[enzyme], reverse=True)
        x_pos = lane_idx + 0.5
        for frag in fragments:
            plt.hlines(y=frag, xmin=x_pos-0.3, xmax=x_pos+0.3, color='black', linewidth=6)
    
    plt.gca().invert_yaxis()
    plt.xticks(range(num_enzymes), enzymes, rotation=45)
    plt.ylabel('Fragment Size (bp)')
    plt.xlabel('Restriction Enzyme (Lane)')
    plt.title('Simulated Gel Electrophoresis')
    plt.grid(axis='y', linestyle='--', alpha=0.3)
    plt.tight_layout()
    plt.show()
    
    if save_file:
        plt.savefig(filename, dpi=300)
        print(f"Gel plot saved to {filename}")

if __name__ == "__main__":
    DNA_SEQUENCE = read_fasta(FILE_PATH)
    DNA_LENGTH = len(DNA_SEQUENCE)
    print(f"DNA Length: {DNA_LENGTH} bp\n")

    fragments_data = {}
    for enzyme, info in RESTRICTION_ENZYMES.items():
        positions, fragments = digest_dna(DNA_SEQUENCE, info["pattern"])
        fragments_data[enzyme] = fragments
        print(f"{enzyme} ({info['site']}):")
        print(f"  Cuts: {len(positions)}")
        print(f"  Fragment lengths: {fragments}\n")
    
    plot_gel(fragments_data)

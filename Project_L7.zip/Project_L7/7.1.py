
"""
1.Take an arbitrary DNA sequence from the NCBI, between 1000 and 3000 nucleotides(letters)
2.Implement a software application that detects repetitions(between 6b and 10b) in this DNA
sequence.
3.Plot the frequencies of the repetitions found.
4.Download 10 influenza genoms.For each, plot the frequencies of found repetitions.
"""
import random
from collections import Counter
import matplotlib.pyplot as plt
import os
import math

def read_fasta(file_path):
    dna_sequence = ""
    with open(file_path, "r") as f:
        for line in f:
            if not line.startswith(">"):
                dna_sequence += line.strip()
    return dna_sequence.upper()

def find_consecutive_repetitions(dna, min_len=6, max_len=10):
    repeats = {}
    for k in range(min_len, max_len + 1):
        counts = Counter()
        i = 0
        while i <= len(dna) - k:
            motif = dna[i:i+k]
            repeat_count = 1
            while dna[i + repeat_count*k : i + (repeat_count+1)*k] == motif:
                repeat_count += 1
            if repeat_count > 1:
                counts[motif] += repeat_count
                i += repeat_count * k
            else:
                i += 1
        repeats[k] = dict(counts)
    return repeats

def plot_repetitions_grid(repeats_list, file_names, motif_length=6, top_n=10):
    num_files = len(repeats_list)
    cols = 2  # adjust columns as needed
    rows = math.ceil(num_files / cols)

    fig, axes = plt.subplots(rows, cols, figsize=(12, rows*3))
    axes = axes.flatten()

    for idx, (repeats, name) in enumerate(zip(repeats_list, file_names)):
        counter = repeats[motif_length]
        if counter:
            top_items = sorted(counter.items(), key=lambda x: x[1], reverse=True)[:top_n]
            motifs, counts = zip(*top_items)
        else:
            motifs, counts = [], []

        axes[idx].bar(range(len(counts)), counts, color="#1f77b4")
        axes[idx].set_xticks(range(len(motifs)))
        axes[idx].set_xticklabels(motifs, rotation=45, ha='right')
        axes[idx].set_ylabel("Count")
        axes[idx].set_title(name)

    # Remove empty subplots
    for i in range(idx+1, len(axes)):
        fig.delaxes(axes[i])

    plt.suptitle(f"Top {top_n} repeated {motif_length}-bp motifs in all genomes", fontsize=16)
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.show()


folder_path = "C:/Users/ana/Desktop/anul4/bioinfo/Project_L7/influenza_fastas"

repeats_list = []
file_names = []

for filename in os.listdir(folder_path):
    if filename.endswith(".fasta") or filename.endswith(".fa"):
        file_path = os.path.join(folder_path, filename)
        sequence = read_fasta(file_path)

        if len(sequence) > 3000:
            start = random.randint(0, len(sequence) - 3000)
            seq_length = random.randint(1000, 3000)
            dna = sequence[start:start + seq_length]
        else:
            dna = sequence

        repetitions = find_consecutive_repetitions(dna)
        repeats_list.append(repetitions)
        file_names.append(filename)

        total_repeats = sum(len(v) for v in repetitions.values())
        print(f"\nFile: {filename}")
        print("Total repeated motifs found:", total_repeats)

        for k in range(6, 11):
            print(f"\n{k}-bp repeats found: {len(repetitions[k])}")
            examples = list(repetitions[k].items())[:5]
            for motif, count in examples:
                print(f"  {motif}: {count} times")

plot_repetitions_grid([repetitions], ["Random DNA Sequence"], motif_length=6, top_n=10)

plot_repetitions_grid(repeats_list, file_names, motif_length=6, top_n=10)

"""
Design an application that uses artificial intelligence, which contains a GUI that allows the users to choose a FASTA file.
The content of the file should be analyzed by using a sliding window of 30 positions.
The content for each sliding window should be used in order to extract the percentages (the relative frequencies) of the symbols found in the alphabet of the sequence.
Thus, the input should be the DNA sequence from the FASTA file, and the output should be the values of the relative frequencies for each symbol in the alphabet of the sequence.
Translate the lines on a chart.

"""

import tkinter as tk
from tkinter import filedialog, messagebox
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from Bio import SeqIO
import numpy as np


DNA_ALPHABET = ["A", "C", "G", "T"]
WINDOW_SIZE = 30

class FastaAnalyzerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("DNA Sliding Window Analyzer")
        self.root.geometry("1000x700")

        self.current_file_path = None

        top_frame = tk.Frame(self.root, pady=5)
        top_frame.pack(side="top", fill="x")

        self.btn_select_file = tk.Button(
            top_frame, text="Select FASTA File", command=self.select_file, font=("Arial", 12)
        )
        self.btn_select_file.pack(side="left", padx=15)

        self.lbl_file_path = tk.Label(
            top_frame, text="No file selected", font=("Arial", 10), fg="gray"
        )
        self.lbl_file_path.pack(side="left")

        # --- Control panel (smoothing) ---
        control_frame = tk.Frame(self.root, pady=5)
        control_frame.pack(side="top", fill="x")

        tk.Label(control_frame, text="Smoothing:", font=("Arial", 10, "bold")).pack(side="left", padx=(20, 5))

        self.smoothing_enabled = tk.BooleanVar(value=True)
        self.chk_enable_smoothing = tk.Checkbutton(
            control_frame, text="Enable", variable=self.smoothing_enabled, command=self.replot
        )
        self.chk_enable_smoothing.pack(side="left")

        tk.Label(control_frame, text="Window Size:").pack(side="left", padx=(20, 5))

        self.smoothing_window_size = tk.IntVar(value=51)
        self.spin_smoothing_window = tk.Spinbox(
            control_frame, from_=3, to=201, increment=2,
            textvariable=self.smoothing_window_size, width=5, command=self.replot
        )
        self.spin_smoothing_window.pack(side="left")

        # --- Chart frame ---
        chart_frame = tk.Frame(self.root)
        chart_frame.pack(side="top", fill="both", expand=True, padx=10, pady=10)

        self.fig = Figure(figsize=(9, 6), dpi=100)
        self.ax = self.fig.add_subplot(111)
        self.canvas = FigureCanvasTkAgg(self.fig, master=chart_frame)
        self.canvas.get_tk_widget().pack(side="top", fill="both", expand=True)

        self.show_start_message()

    def show_start_message(self):
        self.ax.clear()
        self.ax.set_title("Sliding Window Nucleotide Frequencies")
        self.ax.text(0.5, 0.5, "Select a FASTA file to start",
                     ha="center", va="center", fontsize=14, color="gray", transform=self.ax.transAxes)
        self.canvas.draw()

    def select_file(self):
        file_path = filedialog.askopenfilename(
            title="Select a FASTA file",
            filetypes=(("FASTA files", "*.fasta *.fa *.fna"), ("All files", "*.*"))
        )
        if file_path:
            self.current_file_path = file_path
            self.lbl_file_path.config(text=file_path, fg="black")
            self.process_and_plot()

    def replot(self):
        if self.current_file_path:
            self.process_and_plot()

    def apply_smoothing(self, values, window_size):
        if window_size <= 1 or len(values) < window_size:
            return np.array(values)
        kernel = np.ones(window_size) / window_size
        return np.convolve(values, kernel, mode="valid")

    def process_and_plot(self):
        try:
            fasta_sequences = SeqIO.parse(open(self.current_file_path), "fasta")
            first_record = next(fasta_sequences)
            sequence = str(first_record.seq).upper()

            if len(sequence) < WINDOW_SIZE:
                messagebox.showerror("Error", "Sequence length too short for sliding window.")
                return

            frequencies, positions = self.sliding_window(sequence)

            # Smoothing
            if self.smoothing_enabled.get():
                win_size = self.smoothing_window_size.get()
                smoothed = {}
                for base in DNA_ALPHABET:
                    smoothed[base] = self.apply_smoothing(frequencies[base], win_size)

                offset = (win_size - 1) // 2
                adj_positions = positions[offset:-offset]
                self.plot_frequencies(smoothed, adj_positions, first_record.id, win_size)
            else:
                self.plot_frequencies(frequencies, positions, first_record.id)

        except StopIteration:
            messagebox.showerror("Error", "No valid sequence found in file.")
        except Exception as e:
            messagebox.showerror("Error", f"Unexpected error: {e}")
            self.show_start_message()

    def sliding_window(self, sequence):
        freqs = {base: [] for base in DNA_ALPHABET}
        positions = []
        for i in range(len(sequence) - WINDOW_SIZE + 1):
            window = sequence[i:i + WINDOW_SIZE]
            for base in DNA_ALPHABET:
                freqs[base].append(window.count(base) / WINDOW_SIZE)
            positions.append(i)
        return freqs, positions

    def plot_frequencies(self, frequencies, positions, seq_id, smoothing_window=None):
        self.ax.clear()
        colors = {"A": "blue", "C": "green", "G": "orange", "T": "red"}

        for base in DNA_ALPHABET:
            self.ax.plot(positions, frequencies[base], label=f"{base}", color=colors[base], linewidth=1.5)

        title = f"Nucleotide Frequencies for {seq_id}"
        if smoothing_window:
            title += f" (Smoothed, Window={smoothing_window})"

        self.ax.set_title(title)
        self.ax.set_xlabel("Window Start Position")
        self.ax.set_ylabel("Relative Frequency")
        self.ax.set_ylim(0, 1)
        self.ax.grid(True, linestyle="--", alpha=0.6)
        self.ax.legend()
        self.canvas.draw()

def main():
    root = tk.Tk()
    app = FastaAnalyzerApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()

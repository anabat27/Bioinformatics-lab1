"""
 Find in the sequence S only the dinucleotides and trinucleotides that exist, without the use of
 B.F. engine.In order to achieve the results one must veriffy this combination starting
 from the begginning
 eg.: S = "abaa"
"""
S = "TACGTGCGCGCGAGCTATCTACTGACTTACGACTAGTGTAGCTGCATCATCGATCGA"
   
dinucleotides = []
for i in range(len(S) - 1):
     d = S[i:i+2]
     if d not in dinucleotides:  
         dinucleotides.append(d)        

trinucleotides = []
for i in range(len(S) - 2):
    t = S[i:i+3]
    if t not in trinucleotides:  
        trinucleotides.append(t)  

dinuc_total = len(S) - 1
trinuc_total = len(S) - 2
        
print("Dinucleotide percentages:")
for d in dinucleotides:
    percent = (S.count(d) / dinuc_total) * 100
    print(f"{d}: {percent:.2f}%")
    
print("\nTrinucleotide percentages:")
for t in trinucleotides:
    percent = (S.count(t) / trinuc_total) * 100
    print(f"{t}: {percent:.2f}%")

"""
Find the percentage for all the dinucleotide and trinucleotide combinations for the sequence: 
S="TACGTGCGCGCGAGCTATCTACTGACTTACGACTAGTGTAGCTGCATCATCGATCGA".

"""
#1. Build a brute force engine to generate all dinucleotide and trinucleotide combinations.

S="TACGTGCGCGCGAGCTATCTACTGACTTACGACTAGTGTAGCTGCATCATCGATCGA"

alphabet = sorted(set(S))

dinucleotides = []
for a in alphabet:
    for b in alphabet:
        dinucleotides.append(a + b)

trinucleotides = []        
for a in alphabet:
    for b in alphabet:
        for c in alphabet:
            trinucleotides.append(a + b + c)

print("Dinucleotides: ", dinucleotides)
print("Trinucleotides: ", trinucleotides)   

#2. For each combination, find out the percentage inside the S sequence.

dinuc_total = len(S) - 1
trinuc_total = len(S) - 2

dinuc_percentages = {}
for d in dinucleotides:
    dinuc_percentages[d] = (S.count(d) / dinuc_total) * 100

trinuc_percentages = {}
for t in trinucleotides:
    trinuc_percentages[t] = (S.count(t) / trinuc_total) * 100

#3. Show the percentage for each combination in the output of your implementation.

print("Dinucleotide percentages:")
for d, p in dinuc_percentages.items():
    print(f"{d}: {p:.2f}%")

print("\nTrinucleotide percentages:")
for t, p in trinuc_percentages.items():
    print(f"{t}: {p:.2f}%")


    
    
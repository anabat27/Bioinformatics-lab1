import math
import tkinter as tk
from tkinter import scrolledtext
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt


motif_length = 9
bases = ['A', 'C', 'G', 'T']
null_model = 0.25
pseudo_count = 1


def compute_matrices():
    global log_matrix

    # Read sequences
    seq_text = sequences_input.get("1.0", tk.END).strip()
    sequences = [line.strip().upper() for line in seq_text.split("\n") if line.strip()]
    
    S = sequence_input.get("1.0", tk.END).strip().upper()
    
    # Count matrix
    count_matrix = [{b: pseudo_count for b in bases} for _ in range(motif_length)]
    for seq in sequences:
        for i, base in enumerate(seq):
            if base in bases:
                count_matrix[i][base] += 1

    # Relative frequencies
    freq_matrix = [{} for _ in range(motif_length)]
    for i in range(motif_length):
        total = sum(count_matrix[i].values())
        for b in bases:
            freq_matrix[i][b] = count_matrix[i][b] / total

    # Weight matrix
    weight_matrix = [{} for _ in range(motif_length)]
    for i in range(motif_length):
        for b in bases:
            weight_matrix[i][b] = freq_matrix[i][b] / null_model

    # Log-likelihood matrix
    log_matrix = [{} for _ in range(motif_length)]
    for i in range(motif_length):
        for b in bases:
            log_matrix[i][b] = math.log2(weight_matrix[i][b])

    output_text.delete("1.0", tk.END)
    output_text.insert(tk.END, "Count Matrix\n")
    for b in bases:
        output_text.insert(tk.END, f"{b}: " + " ".join(f"{count_matrix[i][b]}" for i in range(motif_length)) + "\n")
    
    output_text.insert(tk.END, "\nRelative Frequencies\n")
    for b in bases:
        output_text.insert(tk.END, f"{b}: " + " ".join(f"{freq_matrix[i][b]:.2f}" for i in range(motif_length)) + "\n")
    
    output_text.insert(tk.END, "\nWeight Matrix\n")
    for b in bases:
        output_text.insert(tk.END, f"{b}: " + " ".join(f"{weight_matrix[i][b]:.2f}" for i in range(motif_length)) + "\n")
    
    output_text.insert(tk.END, "\nLog-Likelihood Matrix\n")
    for b in bases:
        output_text.insert(tk.END, f"{b}: " + " ".join(f"{log_matrix[i][b]:.2f}" for i in range(motif_length)) + "\n")
    
    best_score = -float('inf')
    best_window = ""
    best_pos = -1
    scores = []
    positions = []

    output_text.insert(tk.END, "\nSliding Window Scores\n")
    for i in range(len(S) - motif_length + 1):
        window = S[i:i+motif_length]
        score = sum(log_matrix[pos][base] for pos, base in enumerate(window) if base in bases)
        scores.append(score)
        positions.append(i)
        output_text.insert(tk.END, f"Pos {i:>2}: {window} -> Score: {score:.2f}\n")
        
        if score > best_score:
            best_score = score
            best_window = window
            best_pos = i
    
    output_text.insert(tk.END, "\nConclusion\n")
    if best_score > 0:
        output_text.insert(tk.END, f"Exon-intron border likely at position {best_pos} with motif '{best_window}' (Score: {best_score:.2f})\n")
    else:
        output_text.insert(tk.END, "No exon-intron border signal detected.\n")

    fig, ax = plt.subplots(figsize=(6,2))
    ax.plot(positions, scores, label="PWM Score")
    ax.set_xlabel("Position")
    ax.set_ylabel("Score")
    ax.set_title("Sliding Window Scores")
    ax.legend()
    for widget in plot_frame.winfo_children():
        widget.destroy()
    canvas = FigureCanvasTkAgg(fig, master=plot_frame)
    canvas.draw()
    canvas.get_tk_widget().pack()

root = tk.Tk()
root.title("DNA Motif Finder")

tk.Label(root, text="Motif sequences (one per line):").pack()
sequences_input = scrolledtext.ScrolledText(root, height=10, width=50)
sequences_input.pack()
sequences_input.insert(tk.END, "\n".join([
    "GAGGTAAAC",
    "TCCGTAAGT",
    "CAGGTTGGA",
    "ACAGTCAGT",
    "TAGGTCATT",
    "TAGGTACTG",
    "ATGGTAACT",
    "CAGGTATAC",
    "TGTGTGAGT",
    "AAGGTAAGT"
]))

tk.Label(root, text="Sequence to scan (S):").pack()
sequence_input = scrolledtext.ScrolledText(root, height=2, width=50)
sequence_input.pack()
sequence_input.insert(tk.END, "CAGGTTGGAAACGTAATCAGCGATTACGCATGACGTAA")

tk.Button(root, text="Compute Matrices & Scan Sequence", command=compute_matrices).pack(pady=5)


output_text = scrolledtext.ScrolledText(root, height=20, width=70)
output_text.pack()

plot_frame = tk.Frame(root)
plot_frame.pack()

root.mainloop()

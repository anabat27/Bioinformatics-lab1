import os
import math
import matplotlib.pyplot as plt

FOLDER_PATH = "C:/Users/ana/Desktop/anul4/bioinfo/influenza_fastas"


THRESHOLD = 4.0 
MOTIF_LENGTH = 9

COUNTS = [
    {'A': 3, 'C': 2, 'G': 1, 'T': 4}, 
    {'A': 6, 'C': 2, 'G': 1, 'T': 1}, 
    {'A': 1, 'C': 1, 'G': 7, 'T': 1}, 
    {'A': 0, 'C': 0, 'G': 10,'T': 0}, 
    {'A': 0, 'C': 0, 'G': 0, 'T': 10},
    {'A': 6, 'C': 2, 'G': 1, 'T': 1}, 
    {'A': 7, 'C': 1, 'G': 1, 'T': 1}, 
    {'A': 2, 'C': 1, 'G': 5, 'T': 2}, 
    {'A': 1, 'C': 2, 'G': 1, 'T': 6}  
]


def read_fasta(file_path):
    if not os.path.exists(file_path):
        print(f"File not found: {file_path}")
        return ""

    dna_sequence = ""
    with open(file_path, "r") as f:
        for line in f:
            if not line.startswith(">"):
                dna_sequence += line.strip()
    return dna_sequence.upper()

def build_pwm(counts):
    pwm = []
    num_sequences = 10 
    null_prob = 0.25   
    
    for pos_counts in counts:
        pos_scores = {}
        for base in ['A', 'C', 'G', 'T']:
            freq = pos_counts[base] / num_sequences
            
            if freq > 0:
                score = math.log(freq / null_prob)
            else:
                score = -99.0 
            pos_scores[base] = score
        pwm.append(pos_scores)
    return pwm

def scan_genome(dna, pwm):
    scores = []
    positions = []
    
    for i in range(len(dna) - MOTIF_LENGTH + 1):
        window = dna[i : i + MOTIF_LENGTH]
        current_score = 0
        valid_window = True
        
        for pos in range(MOTIF_LENGTH):
            base = window[pos]
            if base not in ['A', 'C', 'G', 'T']:
                valid_window = False
                break
                
            val = pwm[pos][base]
            
            if val < -10:
                valid_window = False
                break
            current_score += val
        
        if valid_window:
            scores.append(current_score)
            positions.append(i)
        else:
            scores.append(-15) 
            positions.append(i)
            
    return positions, scores

def plot_signal_on_axis(ax, filename, positions, scores, threshold):
    clean_pos = [p for p, s in zip(positions, scores) if s > -14]
    clean_scores = [s for s in scores if s > -14]
    ax.plot(clean_pos, clean_scores, color='#1f77b4', linewidth=0.8, alpha=0.7)
    
    ax.axhline(y=threshold, color='green', linestyle='--', linewidth=1, alpha=0.8)
    
    hits_x = [pos for pos, score in zip(positions, scores) if score > threshold]
    hits_y = [score for score in scores if score > threshold]
    
    if hits_x:
        ax.scatter(hits_x, hits_y, color='red', zorder=5, s=15)
        print(f" -> Found {len(hits_x)} potential motifs in {filename}")
    else:
        print(f" -> No significant motifs found in {filename}")

    short_name = filename.replace(".fasta", "").replace(".txt", "")
    if len(short_name) > 25: short_name = short_name[:22] + "..."
    ax.set_title(short_name, fontsize=9)
    
    ax.grid(True, alpha=0.3)
    ax.set_ylabel("Log-Likelihood", fontsize=8)
    ax.tick_params(axis='both', which='major', labelsize=8)
    ax.set_ylim(bottom=-2, top=10) 

if __name__ == "__main__":
    pwm_matrix = build_pwm(COUNTS)
    print("PWM Matrix built successfully.\n")

    if os.path.exists(FOLDER_PATH):
        files = [f for f in os.listdir(FOLDER_PATH) if f.endswith(".fasta") or f.endswith(".txt")]
        files.sort() 
        num_files = len(files)
        print(f"Found {num_files} files in {FOLDER_PATH}\n")
        
        if num_files == 0:
             print("No fasta files found to process.")
             exit()

        cols = 2
        rows = math.ceil(num_files / cols)
        
        fig, axes = plt.subplots(rows, cols, figsize=(12, 2 * rows), sharex=False, sharey=True)
        axes = axes.flatten() 

        for i, filename in enumerate(files):
            print(f"Processing file {i+1}/{num_files}: {filename}")
            full_path = os.path.join(FOLDER_PATH, filename)
            
            dna = read_fasta(full_path)
            if not dna or len(dna) < MOTIF_LENGTH: 
                print(" Skipping (empty or too short).")
                continue
            
            pos, scores = scan_genome(dna, pwm_matrix)
            
            plot_signal_on_axis(axes[i], filename, pos, scores, THRESHOLD)
            
        for j in range(i + 1, len(axes)):
            fig.delaxes(axes[j])
            
        for ax in axes[-cols:]:
             ax.set_xlabel("Position (bp)", fontsize=9)
             
        plt.tight_layout()
        plt.subplots_adjust(top=0.95) 
        fig.suptitle(f"Splice Site Motif Scan across {num_files} Influenza Genomes (Threshold={THRESHOLD})", fontsize=12)
        print("\nGenerating combined plot...")
        plt.show()
            
    else:
        print(f"Error: Folder not found: {FOLDER_PATH}")

import random
import math
import matplotlib.pyplot as plt

def read_fasta(file_path):
    dna_sequence = ""
    with open(file_path, "r") as f:
        for line in f:
            if not line.startswith(">"):
                dna_sequence += line.strip()
    return dna_sequence.upper()

file_path = "C:/Users/ana/Desktop/anul4/bioinfo/lab5/homosapiens_brain.fasta"
original_sequence = read_fasta(file_path)
sequence_length = len(original_sequence)
print(f"Original sequence length: {sequence_length}")

num_samples = 10
fragments = []

for i in range(num_samples):
    max_len = min(3000, sequence_length)
    frag_length = random.randint(100, max_len)
    start_pos = random.randint(0, sequence_length - frag_length)
    fragments.append({
        "name": f"frag_{i+1}",
        "start": start_pos,
        "length": frag_length,
        "seq": original_sequence[start_pos:start_pos + frag_length]
    })

def size_to_position_bp(bp, bp_min=100, bp_max=3000):
    """Logarithmic scale: smaller fragments travel farther"""
    bp = max(bp_min, min(bp_max, bp))
    lo, hi = math.log10(bp_min), math.log10(bp_max)
    return 1.0 - (math.log10(bp) - lo) / (hi - lo)

plt.figure(figsize=(6.5, 9), dpi=120)
ax = plt.gca()
ax.set_xlim(0, 2)
ax.set_ylim(0, 1)
ax.axis("off")
ax.set_facecolor("black")

ladder_x, ladder_w = 0.1, 0.18
ax.add_patch(plt.Rectangle((ladder_x, 0.05), ladder_w, 0.90,
                           facecolor="#1f1f2e", edgecolor="#111111", linewidth=2))
ax.add_patch(plt.Rectangle((ladder_x+0.01, 0.94), ladder_w-0.02, 0.02,
                           facecolor="none", edgecolor="#e6e6e6", linewidth=1.2))

ladder_bps = [3000, 2000, 1500, 1200, 1000, 800, 700, 600, 500, 400, 300, 200]
for bp in ladder_bps:
    y = 0.05 + 0.90 * size_to_position_bp(bp)
    th = 0.007
    ax.add_patch(plt.Rectangle((ladder_x+0.01, y - th/2), ladder_w-0.02, th,
                               facecolor="#e8e8f0", edgecolor="#cfcfe8"))
    if bp in [3000, 1500, 500]:
        ax.text(ladder_x - 0.03, y, f"{bp} bp", va="center", ha="right",
                fontsize=10, color="#000000", fontweight="bold")

sample_x, sample_w = 0.4, 0.50
ax.add_patch(plt.Rectangle((sample_x, 0.05), sample_w, 0.90,
                           facecolor="#1f1f2e", edgecolor="#111111", linewidth=2))
ax.add_patch(plt.Rectangle((sample_x+0.02, 0.94), sample_w-0.04, 0.02,
                           facecolor="none", edgecolor="#e6e6e6", linewidth=1.5))

for frag in sorted(fragments, key=lambda f: f["length"], reverse=True):
    y = 0.05 + 0.90 * size_to_position_bp(frag["length"])
    thickness = max(0.004, 0.016 - 0.000003 * frag["length"])
    ax.add_patch(plt.Rectangle((sample_x+0.01, y - thickness/2), sample_w-0.02, thickness,
                               facecolor="#e8e8f0", alpha=0.95, edgecolor="#cfcfe8"))
    ax.text(sample_x + sample_w + 0.03, y, f'{frag["name"]} — {frag["length"]} bp',
            va="center", ha="left", fontsize=9, color="#000000", fontweight="bold")

plt.title("Simulated Gel Electrophoresis (10 Samples in Lane 2)")
plt.tight_layout()
plt.show()

print("\nMigration Results:")
for frag in fragments:
    y = size_to_position_bp(frag["length"])
    print(f'{frag["name"]}: Length = {frag["length"]} bp, Migration = {y:.2f}')

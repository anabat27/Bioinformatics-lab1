
import random
import math
import matplotlib.pyplot as plt

def read_fasta(file_path):
    dna_sequence = ""
    with open(file_path, "r") as f:
        for line in f:
            if not line.startswith(">"):
                dna_sequence += line.strip()
    return dna_sequence.upper()

def revcomp(seq):
    """Return the reverse complement of a DNA sequence."""
    return seq.translate(str.maketrans("ACGT", "TGCA"))[::-1]

file_path = "C:/Users/ana/Desktop/anul4/bioinfo/lab5/homosapiens_brain.fasta"
sequence = read_fasta(file_path)
print("Original sequence length =", len(sequence), "bp")

if len(sequence) > 3000:
    start = random.randint(0, len(sequence) - 3000)
    seq_length = random.randint(1000, 3000)
    dna = sequence[start:start + seq_length]
else:
    dna = sequence
print("Selected DNA length =", len(dna), "bp")

enzymes = {
    "EcoRI": "GAATTC",
    "BamHI": "GGATCC",
    "HindIII": "AAGCTT",
    "NotI": "GCGGCCGC",
    "PstI": "CTGCAG"
}

all_fragments = []

for enzyme, site in enzymes.items():
    cut_positions = set()
    pos = dna.find(site)
    while pos != -1:
        cut_positions.add(pos)
        pos = dna.find(site, pos + 1)
    rev_site = revcomp(site)
    pos = dna.find(rev_site)
    while pos != -1:
        cut_positions.add(pos)
        pos = dna.find(rev_site, pos + 1)
    cut_positions = sorted(cut_positions)

    fragments = []
    if not cut_positions:
        fragments = [dna]
        print(f"\n{enzyme}: no cut sites found")
    else:
        prev = 0
        for cut in cut_positions:
            fragments.append(dna[prev:cut])
            prev = cut
        fragments.append(dna[prev:])

        print(f"\n{enzyme} (site {site})")
        print("Fragment lengths (bp):")
        for frag in fragments:
            print(f" {len(frag)}")

    frag_lengths = [len(f) for f in fragments]
    all_fragments.append((enzyme, frag_lengths))

def size_to_position_bp(bp, bp_min=100, bp_max=3000):
    bp = max(bp_min, min(bp_max, bp))
    lo, hi = math.log10(bp_min), math.log10(bp_max)
    return 1.0 - (math.log10(bp) - lo) / (hi - lo)

plt.figure(figsize=(10, 8))
ax = plt.gca()
ax.set_xlim(0, 1.55)
ax.set_ylim(0, 1)
ax.axis("off")
ax.set_facecolor("black")

ladder_x, ladder_w = 0.05, 0.18
ax.add_patch(plt.Rectangle((ladder_x, 0.05), ladder_w, 0.90,
                           facecolor="#1f1f2e", edgecolor="#111111", linewidth=2))
ax.add_patch(plt.Rectangle((ladder_x+0.01, 0.94), ladder_w-0.02, 0.02,
                           facecolor="none", edgecolor="#e6e6e6", linewidth=1.2))

ladder_bps = [3000, 2000, 1500, 1200, 1000, 800, 700, 600, 500, 400, 300, 200]
for bp in ladder_bps:
    y = 0.05 + 0.90*size_to_position_bp(bp)
    th = 0.007
    ax.add_patch(plt.Rectangle((ladder_x+0.01, y-th/2), ladder_w-0.02, th,
                               facecolor="#e8e8f0", edgecolor="#cfcfe8"))
    if bp in [3000, 1500, 500]:
        ax.text(ladder_x-0.03, y, f"{bp} bp", va="center", ha="right",
                fontsize=10, color="#000000", fontweight="bold")
ax.text(ladder_x+ladder_w/2, 0.965, "Ladder", ha="center", va="bottom",
        fontsize=10, color="#000000", fontweight="bold")

lane_w = 0.18
lane_gap = 0.12
lane_x = ladder_x + ladder_w + lane_gap

for enzyme, frag_lengths in all_fragments:
    ax.add_patch(plt.Rectangle((lane_x, 0.05), lane_w, 0.90,
                               facecolor="#1f1f2e", edgecolor="#111111", linewidth=2))
    ax.add_patch(plt.Rectangle((lane_x+0.02, 0.94), lane_w-0.04, 0.02,
                               facecolor="none", edgecolor="#e6e6e6", linewidth=1.5))
    for length in sorted(frag_lengths, reverse=True):
        y = 0.05 + 0.90*size_to_position_bp(length)
        th = max(0.004, 0.016 - 0.000003*length)
        ax.add_patch(plt.Rectangle((lane_x+0.01, y-th/2), lane_w-0.02, th,
                                   facecolor="#e8e8f0", edgecolor="#cfcfe8"))
        ax.text(lane_x+lane_w+0.02, y, f"{length} bp", va="center", ha="left",
                fontsize=8, color="#000000")
    ax.text(lane_x+lane_w/2, 0.965, enzyme, ha="center", va="bottom",
            fontsize=10, color="#000000", fontweight="bold")
    lane_x += lane_w + lane_gap

plt.title("Simulated Restriction Digest Gel", color="white", fontsize=14)
plt.tight_layout()
plt.show()


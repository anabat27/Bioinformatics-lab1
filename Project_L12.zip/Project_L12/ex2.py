import numpy as np
import json

def calculate_transition_matrix(sequence):
    mapping = {'A': 0, 'C': 1, 'G': 2, 'T': 3}
    
    counts = np.zeros((4, 4))
    
    for i in range(len(sequence) - 1):
        current_nuc = sequence[i]
        next_nuc = sequence[i+1]
        
        if current_nuc in mapping and next_nuc in mapping:
            row_idx = mapping[current_nuc]
            col_idx = mapping[next_nuc]
            
            counts[row_idx][col_idx] += 1

    print("Raw Counts Matrix:")
    print(counts)

    row_sums = counts.sum(axis=1, keepdims=True)
    
    row_sums[row_sums == 0] = 1 
    
    transition_matrix = counts / row_sums
    
    return transition_matrix


dna_sequence = "AGCTTTTCATTCTGACTGCAACGGGCAATATGTCTCTGTGTGGATTAAAA"

if len(dna_sequence) != 50:
    print(f"Warning: Sequence length is {len(dna_sequence)}, expected 50.")

matrix = calculate_transition_matrix(dna_sequence)

print("\nCalculated Transition Matrix (Probability):")
print(matrix)


data_to_save = {
    "sequence_length": len(dna_sequence),
    "states": ["A", "C", "G", "T"],
    "transition_matrix": matrix.tolist()
}

filename = "dna_transition_matrix.json"
with open(filename, "w") as f:
    json.dump(data_to_save, f, indent=4)

print(f"\nMatrix saved to '{filename}'")
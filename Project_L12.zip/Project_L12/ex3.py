import numpy as np
import json
import re  

def calculate_word_probabilities(text):
    text = text.lower()
    text = re.sub(r'[^\w\s]', '', text)
    words = text.split()
    
    unique_words = sorted(list(set(words)))
    vocab_size = len(unique_words)
    
    word_to_id = {word: i for i, word in enumerate(unique_words)}
    
    print(f"Total Words: {len(words)}")
    print(f"Unique Words (Vocabulary Size): {vocab_size}")
    
    counts = np.zeros((vocab_size, vocab_size))
    
    for i in range(len(words) - 1):
        curr_word = words[i]
        next_word = words[i+1]
        
        row_idx = word_to_id[curr_word]
        col_idx = word_to_id[next_word]
        
        counts[row_idx][col_idx] += 1
        
    row_sums = counts.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1 
    
    transition_matrix = counts / row_sums
    
    return transition_matrix, word_to_id

input_text = """
Bioinformatics is an interdisciplinary field that develops methods and software tools for understanding biological data, in particular when the data sets are large and complex. As an interdisciplinary field of science, bioinformatics combines biology, computer science, information engineering, mathematics and statistics to analyze and interpret biological data.
"""

print(f"Text Length: {len(input_text)} characters")

matrix, mapping = calculate_word_probabilities(input_text)

print("\nMatrix Shape:", matrix.shape)

data_to_save = {
    "text_length": len(input_text),
    "unique_symbol_mapping": mapping,
    "transition_matrix": matrix.tolist()
}

filename = "word_transition_matrix.json"
with open(filename, "w") as f:
    json.dump(data_to_save, f, indent=4)

print(f"Saved to '{filename}'")
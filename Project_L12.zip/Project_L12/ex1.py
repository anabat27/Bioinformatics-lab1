import numpy as np

def run_prediction_app(matrix, initial_vector):
  
    current_vector = initial_vector.copy()
    
    print(f"Start: {current_vector}")

    for step in range(1, 6):
        new_vector = matrix @ current_vector
        current_vector = new_vector
        print(f"Step {step}: {current_vector}")
        
    return current_vector

matrix_M = np.array([
    [0.5, 0.2, 0.3],
    [0.1, 0.8, 0.1],
    [0.4, 0.0, 0.6]
])
vector_v = np.array([1.0, 0.0, 0.0])


run_prediction_app(matrix_M, vector_v)

print("\nTesting Another Size (2x2)")
matrix_2x2 = np.array([[0.9, 0.1], [0.5, 0.5]])
vector_2x2 = np.array([10.0, 5.0])
run_prediction_app(matrix_2x2, vector_2x2)

from collections import Counter
import matplotlib.pyplot as plt

S = "CGGACTGATCTATCTAAAAAAAAAAAAAAAAAAAAAAAAAAACGTAGCATCTATCGATCTATCTAGCGATCTATCTACTACG"
window_size = 30

def calculate_cg(seq):
    if len(seq) == 0:
        return 0
    return ((seq.count('C') + seq.count('G')) / len(seq)) * 100

def calculate_ic(seq):
    N = len(seq)
    if N < 2:
        return 0
    counts = Counter(seq)
    total = sum(n*(n-1) for n in counts.values())
    raw_ic_percent = (total / (N*N)) * 100
    k = 27.53 / 31.945270672218918
    return raw_ic_percent * k

cg_values = []
ic_values = []
window_centers = []

for i in range(len(S) - window_size + 1):
    window = S[i:i+window_size]
    cg = calculate_cg(window)
    ic = calculate_ic(window)
    cg_values.append(cg)
    ic_values.append(ic)
    window_centers.append((cg, ic))

center_cg = sum(cg_values)/len(cg_values)
center_ic = sum(ic_values)/len(ic_values)

plt.figure(1)
plt.scatter(cg_values, ic_values, alpha=0.7)
plt.xlabel("C+G %")
plt.ylabel("Kappa IC")
plt.title("Pattern (Sequence S)")
plt.grid(True, linestyle='--', alpha=0.5)

plt.figure(2)
x_centers = [c[0] for c in window_centers]
y_centers = [c[1] for c in window_centers]
plt.scatter(x_centers, y_centers, alpha=0.6, label='Window centers')
plt.scatter([center_cg], [center_ic], color='red', s=100, label='Center of weight')
plt.xlabel("C+G %")
plt.ylabel("Kappa IC")
plt.title("Centers of Windows and Overall Center")
plt.legend()
plt.grid(True, linestyle='--', alpha=0.5)

plt.show()

print(f"CG = {calculate_cg(S):.2f}")
print(f"IC = {calculate_ic(S):.2f}")
print(f"Center of weight CG = {center_cg:.2f}")
print(f"Center of weight IC = {center_ic:.2f}")

#Version of IC without scaling (mathematically standard)
# def calculate_ic_standard(seq):
#     N = len(seq)
#     if N < 2:
#         return 0
#     counts = Counter(seq)
#     total = sum(n*(n-1) for n in counts.values())
#     return (total / (N*(N-1))) * 100
# Using this version, the IC for the full sequence would be ~32.34







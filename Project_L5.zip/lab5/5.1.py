import random

def read_fasta(file_path):
    dna_sequence = ""
    with open(file_path, "r") as f:
        for line in f:
            if not line.startswith(">"):
                dna_sequence += line.strip()
    return dna_sequence.upper()

file_path = "C:/Users/ana/Desktop/anul4/bioinfo/lab5/homosapiens_brain.fasta"
original_sequence = read_fasta(file_path)
sequence_length = len(original_sequence)
print(f"Original sequence length: {sequence_length}")

num_samples = 2000
fragments = []
for _ in range(num_samples):
    frag_length = random.randint(100, 150)
    start_pos = random.randint(0, sequence_length - frag_length)
    fragments.append(original_sequence[start_pos:start_pos + frag_length])

print(f"Generated {len(fragments)} samples.")

min_overlap = 10
assembled = fragments[0]

for fragment in fragments[1:]:
    overlap_len = 0
    for i in range(min_overlap, min(len(assembled), len(fragment)) + 1):
        if assembled[-i:] == fragment[:i]:
            overlap_len = i
    if overlap_len > 0:
        assembled += fragment[overlap_len:]
        continue  

    overlap_len = 0
    for i in range(min_overlap, min(len(assembled), len(fragment)) + 1):
        if assembled[:i] == fragment[-i:]:
            overlap_len = i
    if overlap_len > 0:
        assembled = fragment[:-overlap_len] + assembled

reconstructed_sequence = assembled
print(f"Reconstructed sequence length: {len(reconstructed_sequence)}")


"""
Download from NCBI the FASTA file containing the COVID-19 genome and the influenza genome.
Use the AI to compare the codon frequencies between the two.
a)Make a chart that shows the top 10 most frequent codons for COVID-19.
b)Make a chart that shows the top 10 most frequent codons for influenza.
c)Compare the two results and show the most frequent codons between the two.
d)Show the output of the console top 3 amino acids for each genome.
"""
from collections import Counter
import matplotlib.pyplot as plt

genetic_code = {
    "UUU": "Phe", "UUC": "Phe",
    "UUA": "Leu", "UUG": "Leu", "CUU": "Leu", "CUC": "Leu", "CUA": "Leu", "CUG": "Leu",
    "AUU": "Ile", "AUC": "Ile", "AUA": "Ile",
    "AUG": "Met",
    "GUU": "Val", "GUC": "Val", "GUA": "Val", "GUG": "Val",
    "UCU": "Ser", "UCC": "Ser", "UCA": "Ser", "UCG": "Ser", "AGU": "Ser", "AGC": "Ser",
    "CCU": "Pro", "CCC": "Pro", "CCA": "Pro", "CCG": "Pro",
    "ACU": "Thr", "ACC": "Thr", "ACA": "Thr", "ACG": "Thr",
    "GCU": "Ala", "GCC": "Ala", "GCA": "Ala", "GCG": "Ala",
    "UAU": "Tyr", "UAC": "Tyr",
    "CAU": "His", "CAC": "His",
    "CAA": "Gln", "CAG": "Gln",
    "AAU": "Asn", "AAC": "Asn",
    "AAA": "Lys", "AAG": "Lys",
    "GAU": "Asp", "GAC": "Asp",
    "GAA": "Glu", "GAG": "Glu",
    "UGU": "Cys", "UGC": "Cys",
    "UGG": "Trp",
    "CGU": "Arg", "CGC": "Arg", "CGA": "Arg", "CGG": "Arg", "AGA": "Arg", "AGG": "Arg",
    "GGU": "Gly", "GGC": "Gly", "GGA": "Gly", "GGG": "Gly",
    "UAA": "Stop", "UAG": "Stop", "UGA": "Stop"
}

def read_fasta(file_path):
    sequence = ""
    with open(file_path, "r") as f:
        for line in f:
            line = line.strip()
            if not line.startswith(">"):
                sequence += line
    return sequence.upper().replace("T", "U")


def count_codons(seq):
    codons = [seq[i:i+3] for i in range(0, len(seq) - 2, 3)]
    codons = [c for c in codons if len(c) == 3]
    return Counter(codons)


def show_top_codons_chart(codon_counts, title):
    top10 = codon_counts.most_common(10)
    codons, counts = zip(*top10)
    plt.figure(figsize=(8, 4))
    plt.bar(codons, counts, color="skyblue")
    plt.title(title)
    plt.xlabel("Codon")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.show()


def top_3_amino_acids(codon_counts):
    amino_counts = Counter()
    for codon, freq in codon_counts.items():
        aa = genetic_code.get(codon)
        if aa and aa != "Stop":
            amino_counts[aa] += freq
    return amino_counts.most_common(3)



if __name__ == "__main__":
    covid_seq = read_fasta("covid-19.fasta")
    flu_seq = read_fasta("influenza.fasta")

    covid_codons = count_codons(covid_seq)
    flu_codons = count_codons(flu_seq)

    show_top_codons_chart(covid_codons, "Top 10 Codons in COVID-19")

    show_top_codons_chart(flu_codons, "Top 10 Codons in Influenza")

    covid_top = {c for c, _ in covid_codons.most_common(10)}
    flu_top = {c for c, _ in flu_codons.most_common(10)}
    common = covid_top & flu_top
    print("Most frequent codons in both genomes:", ", ".join(common) if common else "None")

    print("\nTop 3 Amino Acids in COVID-19:")
    for aa, freq in top_3_amino_acids(covid_codons):
        print(f" - {aa}: {freq}")

    print("\nTop 3 Amino Acids in Influenza:")
    for aa, freq in top_3_amino_acids(flu_codons):
        print(f" - {aa}: {freq}")
